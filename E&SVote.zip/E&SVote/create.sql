CREATE DATABASE esvote;

USE esvote;

CREATE TABLE users
(
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(20) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    VoteFlag TINYINT(1) NOT NULL DEFAULT 0
);

CREATE TABLE votes
(
    VoteID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(100) NOT NULL,
    Description TEXT,
    PublicKeyQ varchar(1024),
    PublicKeyG varchar(1024),
    PublicKeyH varchar(1024),
    Result varchar(100)
);

CREATE TABLE vote_options
(
    OptionID INT AUTO_INCREMENT PRIMARY KEY,
    VoteID INT,
    OptionText VARCHAR(255) NOT NULL,
    EncryptedVotes VARCHAR(255),
    FOREIGN KEY (VoteID) REFERENCES votes(VoteID)
);
