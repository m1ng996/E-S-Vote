# ElGamal.py
import random
import sympy
from .util import isPrime, powmod, get_pri_root, getinv, generateLargePrime


class ElGamalPublicKey:
    def __init__(self, p, g, h):
        self.p = p  # prime
        self.g = g  # root
        self.h = h  # g^x mod q

    def __repr__(self):
        return f'PublicKey(q={self.p}, g={self.g}, h={self.h})'

    def encrypt(self, plaintext):
        y = random.randint(1, self.p - 1)
        c1 = powmod(self.g, y, self.p)
        s = powmod(self.h, y, self.p)
        c2 = plaintext * s % self.p
        return (c1, c2)

    def evaluate(self, c1, c2):
        return (c1[0] * c2[0] % self.p, c1[1] * c2[1] % self.p)


class ElGamalPrivateKey:
    def __init__(self, p, x):
        self.p = p  # prime
        self.x = x  # private key

    def __repr__(self):
        return f'PrivateKey(p={self.p}, x={self.x})'

    def decrypt(self, ciphertext):
        c1, c2 = ciphertext
        s = powmod(c1, self.x, self.p)
        invs = getinv(s, self.p)
        plaintext = c2 * invs % self.p
        # print(f"Decrypting: c1={c1}, c2={c2}, s={s}, invs={invs}, plaintext={plaintext}") #Check
        return plaintext


def keyGen(keysize=128):
    num = random.randint(2, 3)

    def generate_p():
        while True:
            p = 1
            fac = [2]
            if num == 2:
                fac.append(generateLargePrime(keysize // 2 - 1))
                fac.append(generateLargePrime(keysize // 2))
            else:
                fac.append(generateLargePrime(keysize // 4 - 1))
                fac.append(generateLargePrime(keysize // 4))
                fac.append(generateLargePrime(keysize // 2))
            for x in fac:
                p = p * x
            p = p + 1
            if isPrime(p) == True:
                return (p, fac)

    (p, fac) = generate_p()
    g = get_pri_root(fac, p)
    x = random.randint(1, p - 1)
    h = powmod(g, x, p)
    return ElGamalPublicKey(p, g, h), ElGamalPrivateKey(p, x)


def save_key(key, filename, mode=0):
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            if mode == 0:
                f.write(f'{key.p}\n{key.g}\n{key.h}')
            elif mode == 1:
                f.write(f'{key.p}\n{key.x}')
            return True
    except Exception as e:
        print(e)
        return False


def load_key(filename, mode=0):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            if mode == 0:
                p = int(lines[0].strip())
                g = int(lines[1].strip())
                h = int(lines[2].strip())
                return ElGamalPublicKey(p, g, h)
            elif mode == 1:
                p = int(lines[0].strip())
                x = int(lines[1].strip())
                return ElGamalPrivateKey(p, x)
    except Exception as e:
        print(e)
        return None
