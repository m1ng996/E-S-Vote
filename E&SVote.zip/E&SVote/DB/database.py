# database.py
import pymysql
import config


def get_db_connection():
    connection = pymysql.connect(host=config.DB_HOST,
                                 user=config.DB_USER,
                                 password=config.DB_PASSWORD,
                                 db=config.DB_NAME,
                                 charset='utf8mb4',
                                 cursorclass=pymysql.cursors.DictCursor)
    return connection


def check_login(username, password):

    if username == "admin" and password == "123456":
        return 'admin'

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT UserID, VoteFlag FROM users WHERE UserName=%s AND Password=%s", (username, password))
            result = cursor.fetchone()
            if result:
                if result['VoteFlag'] == 1:
                    return 'user_yes'
                else:
                    return 'user_no'
            else:
                return None
    finally:
        conn.close()


def register_user(username, password):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("INSERT INTO users (UserName, Password) VALUES (%s, %s)", (username, password))
            conn.commit()
        return True
    except pymysql.err.IntegrityError:
        return False
    finally:
        conn.close()


def get_latest_election():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM votes ORDER BY VoteID DESC LIMIT 1")
            latest_election = cursor.fetchone()
            if latest_election:
                cursor.execute("SELECT OptionID, OptionText FROM vote_options WHERE VoteID = %s", (latest_election['VoteID'],))
                latest_election['options'] = [{'OptionID': option['OptionID'], 'OptionText': option['OptionText']} for option in cursor.fetchall()]
            return latest_election
    finally:
        conn.close()


def create_new_election(title, description, options, public_key):

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "INSERT INTO votes (Title, Description, PublicKeyQ, PublicKeyG, PublicKeyH) VALUES (%s, %s, %s, %s, %s)",
                (title, description, str(public_key.p), str(public_key.g), str(public_key.h))
            )
            vote_id = cursor.lastrowid

            # 插入选举选项
            for option_text in options:
                if option_text:
                    cursor.execute("INSERT INTO vote_options (VoteID, OptionText) VALUES (%s, %s)",
                                   (vote_id, option_text)
                                   )
            conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()


def update_user_vote_flag(username, flag):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE users SET VoteFlag = %s WHERE UserName = %s", (int(flag), username))
            conn.commit()
    except Exception as e:
        print(f"Error updating user vote flag: {str(e)}")
        conn.rollback()
    finally:
        conn.close()


def reset_all_users_vote_flags(flag):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE users SET VoteFlag = %s", (int(flag)))
            conn.commit()
    except Exception as e:
        print(f"Error resetting user vote flags: {str(e)}")
        conn.rollback()
    finally:
        conn.close()


def count_unvoted_users():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as count FROM users WHERE VoteFlag = 0")
            result = cursor.fetchone()
            return result['count'] if result else 0
    finally:
        conn.close()


def get_encrypted_votes(vote_id):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT OptionText, EncryptedVotes FROM vote_options WHERE VoteID = %s", (vote_id,))
            return cursor.fetchall()
    finally:
        conn.close()


def update_final_result(vote_id, result):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE votes SET Result = %s WHERE VoteID = %s", (result, vote_id))
            conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()


def get_result():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT Title, Description, Result FROM votes ORDER BY VoteID DESC LIMIT 1")
            vote_details = cursor.fetchone()
            return vote_details
    finally:
        conn.close()