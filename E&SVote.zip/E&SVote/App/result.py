# result.py
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QPushButton, QMessageBox
from DB.database import get_result


class ResultWindow(QWidget):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Election Result - E&SVote')
        layout = QVBoxLayout(self)

        self.resize(400, 300)

        # Election Information
        self.title_label = QLabel("Current election is :", self)
        self.description_label = QLabel("Description:", self)
        self.result_label = QLabel("Winners", self)

        # Refresh button
        self.refresh_button = QPushButton('Refresh',self)
        self.refresh_button.clicked.connect(self.updateResult)
        self.refresh_button.clicked.connect(lambda: QMessageBox.information(self, 'refresh', 'Latest results have been obtained'))

        # Return button
        self.back_button = QPushButton('Return',self)
        self.back_button.clicked.connect(self.returnLastPage)

        # layouts
        layout.addWidget(self.title_label)
        layout.addWidget(self.description_label)
        layout.addWidget(self.result_label)
        layout.addWidget(self.refresh_button)
        layout.addWidget(self.back_button)
        self.setLayout(layout)

        self.updateResult()

    def updateResult(self):
        vote_details = get_result()
        if vote_details:
            self.title_label.setText(f"Current election is : {vote_details['Title']}")
            self.description_label.setText(f"Description: {vote_details['Description']}")

            # Get the result
            if vote_details['Result']:
                option_info, votes_info = vote_details['Result'].split(', ')
                option = option_info.split(': ')[1]
                votes_count = votes_info.split(': ')[1]
                self.result_label.setText(f"Winner is {option}，and the number of votes is {votes_count}")
            else:
                self.result_label.setText("There is no result available")
        else:
            self.title_label.setText("No election available")
            self.description_label.setText("")
            self.result_label.setText("")

    def returnLastPage(self):
        if self.username == 'admin':
            from .admin import AdminWindow
            self.admin_window = AdminWindow()
            self.admin_window.show()
        else:
            QMessageBox.information(self, 'exit', 'You have been logged out')
            from .login import LoginWindow
            self.login_window = LoginWindow()
            self.login_window.show()
        self.close()


