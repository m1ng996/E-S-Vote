# register.py
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QCursor, QPixmap
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox
from DB.database import register_user


class RegisterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

        self.resize(400, 300)

    def initUI(self):
        self.setWindowTitle('Sign Up - E&SVote')
        layout = QVBoxLayout()

        self.resize(400, 300)

        # Image Label
        self.image_label = QLabel(self)
        pixmap = QPixmap('img/logo.PNG')
        scaled_pixmap = pixmap.scaled(100, 100)
        self.image_label.setPixmap(scaled_pixmap)
        self.image_label.setAlignment(Qt.AlignCenter)

        # Input Fields
        self.username_label = QLabel('Username')
        self.username_input = QLineEdit()

        self.password_label = QLabel('Password')
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)

        self.password2_label = QLabel('Password Confirmation')
        self.password2_input = QLineEdit()
        self.password2_input.setEchoMode(QLineEdit.Password)

        # Buttons
        self.register_button = QPushButton('Sign Up')
        self.register_button.clicked.connect(self.register)

        self.back_label = QLabel('<html>'
                                 '  <head/>'
                                 '      <body>'
                                 '          <p>'
                                 '              <span style="font-size:10pt; font-weight:600;">'
                                 '                  Already have an account?'
                                 '              </span>'
                                 '              <br/>'
                                 '              <a href="#" style="color:#0000FF;">'
                                 '                  Login now'
                                 '              </a>'
                                 '          </p>'
                                 '      </body>'
                                 '</html>')
        self.back_label.setAlignment(Qt.AlignCenter)
        self.back_label.setOpenExternalLinks(False)
        self.back_label.setCursor(QCursor(Qt.PointingHandCursor))
        self.back_label.linkActivated.connect(self.back_to_login)

        # layouts
        layout.addWidget(self.image_label)
        layout.addWidget(self.username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.password2_label)
        layout.addWidget(self.password2_input)
        layout.addWidget(self.register_button)
        layout.addWidget(self.back_label)

        self.setLayout(layout)

    def register(self):
        username = self.username_input.text().strip()
        password = self.password_input.text()
        password2 = self.password2_input.text()

        # Data validation
        if not username or len(username) > 20:
            QMessageBox.warning(self, 'fail', 'Username is required and must be less than 20.')
            return

        if not password or not password2:
            QMessageBox.warning(self, 'fail', 'Password and confirmation password are required.')
            return

        if password != password2:
            QMessageBox.warning(self, 'fail', 'The password is not the same.')
            return

        # Attempt to register user
        if register_user(username, password):
            QMessageBox.information(self, 'success', 'You have successfully registered!')
            self.back_to_login()
        else:
            QMessageBox.warning(self, 'fail', 'Username has already been registered.')

    def back_to_login(self):
        from .login import LoginWindow
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()
