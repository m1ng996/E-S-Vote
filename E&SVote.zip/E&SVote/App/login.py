# login.py
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox
from PyQt5.QtGui import QPixmap, QCursor
from PyQt5.QtCore import Qt
from .register import RegisterWindow
from .admin import AdminWindow
from .voting import VotingWindow
from .result import ResultWindow
from DB.database import check_login


class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.username = None

    def initUI(self):
        self.setWindowTitle('Login - E&SVote')
        layout = QVBoxLayout(self)

        self.resize(400, 300)

        # Image
        self.image_label = QLabel(self)
        pixmap = QPixmap('img/logo.PNG')
        scaled_pixmap = pixmap.scaled(100, 100)
        self.image_label.setPixmap(scaled_pixmap)
        self.image_label.setAlignment(Qt.AlignCenter)

        # Input Fields
        self.username_label = QLabel('Username', self)
        self.username_input = QLineEdit(self)

        self.password_label = QLabel('Password',self)
        self.password_input = QLineEdit(self)
        self.password_input.setEchoMode(QLineEdit.Password)

        # buttons
        self.login_button = QPushButton('Login',self)
        self.login_button.clicked.connect(self.login)

        self.signup_label = QLabel('<html>'
                                   '    <head/>'
                                   '        <body>'
                                   '            <p>'
                                   '                <span style="font-size:10pt; font-weight:600;">'
                                   '                    Don\'t have an account?'
                                   '                </span>'
                                   '                <br/>'
                                   '                <a href="#" style="color:#0000FF;">'
                                   '                    Sign up now'
                                   '                </a>'
                                   '            </p>'
                                   '        </body>'
                                   '</html>', self)
        self.signup_label.setAlignment(Qt.AlignCenter)
        self.signup_label.setOpenExternalLinks(False)
        self.signup_label.setCursor(QCursor(Qt.PointingHandCursor))
        self.signup_label.linkActivated.connect(self.open_register)

        # layouts
        layout.addWidget(self.image_label)
        layout.addWidget(self.username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.login_button)
        layout.addWidget(self.signup_label)

        self.setLayout(layout)

    def login(self):
        username = self.username_input.text()
        password = self.password_input.text()
        login_result = check_login(username, password)

        if login_result == 'admin':
            QMessageBox.information(self, 'success', 'Admin login successfully！')
            self.admin_window = AdminWindow()
            self.admin_window.show()
            self.close()
        elif login_result == 'user_no':
            QMessageBox.information(self, 'success', 'login successfully！')
            self.voting_window = VotingWindow(username)
            self.voting_window.show()
            self.close()
        elif login_result == 'user_yes':
            QMessageBox.information(self, 'done', 'You have already voted or the election has been closed!')
            self.result_window = ResultWindow(username)
            self.result_window.show()
            self.close()
        else:
            QMessageBox.warning(self, 'fail', 'Wrong username or password！')

    def open_register(self):
        self.register_window = RegisterWindow()
        self.register_window.show()
        self.close()
