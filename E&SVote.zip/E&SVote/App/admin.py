# admin.py
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QPushButton, QListWidget, QMessageBox, QFileDialog, \
    QHBoxLayout, QFormLayout
from .create_election import CreateElectionWindow
from DB.database import get_latest_election, count_unvoted_users, get_encrypted_votes, update_final_result, reset_all_users_vote_flags
from HE.ElGamal import load_key
from .result import ResultWindow
from math import log


class AdminWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.latest_election = get_latest_election()
        self.prime_numbers = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Admin Control Panel')
        layout = QVBoxLayout(self)

        self.resize(400, 300)

        # Title
        self.title_label = QLabel("Election Management", self)
        self.title_label.setAlignment(Qt.AlignCenter)

        # Election Information
        self.election_info_label = QLabel('The latest election information:', self)
        self.election_title_label = QLabel('Title: ', self)
        self.election_desc_label = QLabel('Description: ', self)
        self.options_list_widget = QListWidget(self)

        self.refresh_election_info()

        # Buttons
        button_layout = QHBoxLayout()

        self.create_election_button = QPushButton('Create', self)
        self.create_election_button.clicked.connect(self.open_create_election)

        self.publish_result_button = QPushButton('Publish Result', self)
        self.publish_result_button.clicked.connect(self.publish_result)

        self.result_button = QPushButton('View Result', self)
        self.result_button.clicked.connect(self.view_result)

        self.logout_button = QPushButton('Logout', self)
        self.logout_button.clicked.connect(self.logout)

        # Layouts
        layout.addWidget(self.title_label)
        layout.addWidget(self.election_info_label)
        layout.addWidget(self.election_title_label)
        layout.addWidget(self.election_desc_label)
        layout.addWidget(self.options_list_widget)
        button_layout.addWidget(self.create_election_button)
        button_layout.addWidget(self.publish_result_button)
        button_layout.addWidget(self.result_button)
        layout.addLayout(button_layout)
        layout.addWidget(self.logout_button)

        self.setLayout(layout)

    def refresh_election_info(self):
        self.latest_election = get_latest_election()
        if self.latest_election:
            self.election_title_label.setText(f"Title: {self.latest_election['Title']}")
            self.election_desc_label.setText(f"Description: {self.latest_election['Description']}")
            self.options_list_widget.clear()
            for option in self.latest_election['options']:
                self.options_list_widget.addItem(option['OptionText'])
        else:
            QMessageBox.information(self, 'empty', 'There is no election, you can create one by clicking create button.')

    def open_create_election(self):
        self.create_election_window = CreateElectionWindow()
        self.create_election_window.election_created.connect(self.refresh_election_info)
        self.create_election_window.show()

    def publish_result(self):
        num_unvoted = count_unvoted_users()
        if num_unvoted:
            reply = QMessageBox.question(self, 'publish', f'The current number of users who have not finished voting is：{num_unvoted}。\nDo you want to publish the result now?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        else:
            reply = QMessageBox.question(self, 'publish', f'All users have finished voting。\nDo you want to publish the result now?', QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if reply == QMessageBox.Yes:
            filename, _ = QFileDialog.getOpenFileName(self, "Select Private Key File", "", "Text Files (*.txt)")
            if filename:
                private_key = load_key(filename, mode=1)
                if private_key:
                    encrypted_votes = get_encrypted_votes(self.latest_election['VoteID'])
                    results = {}
                    for record in encrypted_votes:
                        if record['EncryptedVotes']:
                            c1, c2 = map(int, record['EncryptedVotes'].split(','))
                            decrypted_votes = private_key.decrypt((c1, c2))

                            for prime in self.prime_numbers:
                                if decrypted_votes % prime == 0:
                                    decrypted_votes = int(log(decrypted_votes, prime))
                                    results[record['OptionText']] = decrypted_votes
                        else:
                            results[record['OptionText']] = 0

                    max_votes_option_text = max(results, key=results.get)
                    max_votes = results[max_votes_option_text]
                    result_text = f'Option: {max_votes_option_text}, Votes: {max_votes}'
                    update_final_result(self.latest_election['VoteID'], result_text)
                    QMessageBox.information(self, 'success', 'The result has been published successfully.')
                    reset_all_users_vote_flags(1)
                    self.result_window = ResultWindow("admin")
                    self.result_window.show()
                    self.close()
                else:
                    QMessageBox.warning(self, 'fail', 'Can not load private key file.')

    def view_result(self):
        self.close()
        self.result_window = ResultWindow("admin")
        self.result_window.show()

    def logout(self):
        from .login import LoginWindow
        QMessageBox.information(self, 'exit', 'You have been logged out.')
        self.close()
        self.login_window = LoginWindow()
        self.login_window.show()
