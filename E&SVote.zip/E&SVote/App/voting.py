# voting.py
from PyQt5.QtWidgets import (QWidget, QLabel, QVBoxLayout, QRadioButton, QPushButton, QMessageBox)
from DB.database import get_latest_election, get_db_connection, update_user_vote_flag
from HE.ElGamal import ElGamalPublicKey
from .result import ResultWindow


class VotingWindow(QWidget):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.latest_election = get_latest_election()
        self.radio_buttons = []
        self.prime_numbers = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Election - E&SVote')
        layout = QVBoxLayout(self)

        self.resize(400, 300)

        self.welcome_label = QLabel(f'Welcome {self.username}!',self)
        layout.addWidget(self.welcome_label)

        if self.latest_election:
            self.election_info_label = QLabel(
                f"Current Election: {self.latest_election['Title']}\nDescription: {self.latest_election['Description']}", self)
            layout.addWidget(self.election_info_label)

            self.options_group = QVBoxLayout()
            i = 0
            for option in self.latest_election['options']:
                radio_button = QRadioButton(option['OptionText'])
                radio_button.option_id = option['OptionID']
                radio_button.prime_number = self.prime_numbers[i]
                i += 1
                self.options_group.addWidget(radio_button)
                self.radio_buttons.append(radio_button)

            layout.addLayout(self.options_group)

            self.vote_button = QPushButton('Submit',self)
            self.vote_button.clicked.connect(self.submit_vote)
            layout.addWidget(self.vote_button)
        else:
            self.no_election_label = QLabel('There are no Elections',self)
            layout.addWidget(self.no_election_label)

        self.logout_button = QPushButton('Logout', self)
        self.logout_button.clicked.connect(self.logout)
        layout.addWidget(self.logout_button)

        self.setLayout(layout)

    def logout(self):
        from .login import LoginWindow
        QMessageBox.information(self, 'exit', 'You have been logged out.')
        self.close()
        self.login_window = LoginWindow()
        self.login_window.show()

    def submit_vote(self):
        selected_option_id = None
        selected_prime = None
        for radio_button in self.radio_buttons:
            if radio_button.isChecked():
                selected_option_id = radio_button.option_id
                selected_prime = radio_button.prime_number
                break

        if selected_option_id is None:
            QMessageBox.warning(self, 'fail', 'Please select an option!')
            return

        q = int(self.latest_election['PublicKeyQ'])
        g = int(self.latest_election['PublicKeyG'])
        h = int(self.latest_election['PublicKeyH'])
        public_key = ElGamalPublicKey(q, g, h)

        encrypted_vote = public_key.encrypt(selected_prime)
        self.store_encrypted_vote(selected_option_id, encrypted_vote)

    def store_encrypted_vote(self, option_id, encrypted_vote):
        encrypted_vote_str = f"{encrypted_vote[0]},{encrypted_vote[1]}"
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT EncryptedVotes FROM vote_options WHERE OptionID = %s", (option_id,))
                result = cursor.fetchone()
                if result and result['EncryptedVotes'] is not None:
                    # Homomorphic multiplication
                    old_encrypted_vote_str = result['EncryptedVotes']
                    old_c1, old_c2 = map(int, old_encrypted_vote_str.split(','))

                    q = int(self.latest_election['PublicKeyQ'])
                    g = int(self.latest_election['PublicKeyG'])
                    h = int(self.latest_election['PublicKeyH'])
                    public_key = ElGamalPublicKey(q, g, h)

                    new_encrypted_vote = public_key.evaluate((old_c1, old_c2), encrypted_vote)
                    new_encrypted_vote_str = f"{new_encrypted_vote[0]},{new_encrypted_vote[1]}"
                else:
                    new_encrypted_vote_str = encrypted_vote_str

                cursor.execute("""
                    UPDATE vote_options
                    SET EncryptedVotes = %s
                    WHERE OptionID = %s
                """, (new_encrypted_vote_str, option_id))

                update_user_vote_flag(self.username, 1)
                conn.commit()
                QMessageBox.information(self, 'success', 'Your vote is now encrypted and submitted.')
                self.close()
                self.result_window = ResultWindow(self.username)
                self.result_window.show()
        except Exception as e:
            conn.rollback()
            QMessageBox.warning(self, 'fail', f'Can not store the encrypted votes：{str(e)}')
        finally:
            conn.close()
