# create_election.py
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QVBoxLayout, QPushButton, QTextEdit, QMessageBox, QFormLayout, \
    QHBoxLayout
from PyQt5.QtCore import pyqtSignal
from DB.database import create_new_election, reset_all_users_vote_flags
from HE.ElGamal import keyGen, save_key
import os


class CreateElectionWindow(QWidget):
    election_created = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.option_inputs = []
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Create Election - E&SVote')
        layout = QVBoxLayout(self)

        # Create Election Information
        self.form_layout = QFormLayout()
        self.title_label = QLabel('Title:',self)
        self.title_input = QLineEdit(self)
        self.description_label = QLabel('Description:',self)
        self.description_input = QTextEdit(self)

        first_option_input = QLineEdit(self)
        first_option_input.setPlaceholderText("Option 1")
        self.option_inputs.append(first_option_input)

        # buttons
        self.button_layout = QHBoxLayout()
        self.add_option_button = QPushButton('Add Option', self)
        self.add_option_button.clicked.connect(self.add_option)

        self.remove_option_button = QPushButton('Remove Option', self)
        self.remove_option_button.clicked.connect(self.remove_option)

        self.create_election_button = QPushButton('Create Election', self)
        self.create_election_button.clicked.connect(self.create_election)

        self.back_button = QPushButton('Return', self)
        self.back_button.clicked.connect(self.close)

        # Layouts
        self.form_layout.addRow(self.title_label, self.title_input)
        self.form_layout.addRow(self.description_label, self.description_input)
        self.form_layout.addRow(QLabel('Option 1:'), first_option_input)
        layout.addLayout(self.form_layout)
        self.button_layout.addWidget(self.add_option_button)
        self.button_layout.addWidget(self.remove_option_button)
        layout.addLayout(self.button_layout)
        layout.addWidget(self.create_election_button)
        layout.addWidget(self.back_button)

        self.setLayout(layout)

    def add_option(self):
        option_number = len(self.option_inputs) + 1
        new_option_input = QLineEdit()
        new_option_input.setPlaceholderText(f"Option {option_number}")
        self.option_inputs.append(new_option_input)
        self.form_layout.addRow(QLabel(f'Option {option_number}:'), new_option_input)

    def remove_option(self):
        if len(self.option_inputs) > 1:
            option_to_remove = self.option_inputs.pop()
            index = self.form_layout.getWidgetPosition(option_to_remove)[0]
            self.form_layout.removeRow(index)

    def create_election(self):
        title = self.title_input.text()
        description = self.description_input.toPlainText()
        options = [option.text() for option in self.option_inputs if option.text().strip()]

        try:
            # Generate Keys
            pubkey, prikey = keyGen(keysize=128)
            keys_directory = './keys/'
            os.makedirs(keys_directory, exist_ok=True)
            pubkey_path = os.path.join(keys_directory, 'public_key.txt')
            prikey_path = os.path.join(keys_directory, 'private_key.txt')
            save_key(pubkey, pubkey_path, mode=0)
            save_key(prikey, prikey_path, mode=1)

            create_new_election(title, description, options, pubkey)
            reset_all_users_vote_flags(0)
            QMessageBox.information(self, 'success', 'The election and key are generated and saved successfully.')
            self.election_created.emit()
            self.close()
        except Exception as e:
            QMessageBox.warning(self, 'fail', f'Error during creation：{str(e)}')
