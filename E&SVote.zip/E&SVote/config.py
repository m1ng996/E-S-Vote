# config.py
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = 'qwer1234'
DB_NAME = 'esvote'
